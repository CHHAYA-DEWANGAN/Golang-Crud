package models

type Result struct {
	Status  string `json:"status"`
	Message string `json:"message"`
}
